/*
*********************************************************************************************************
*                                              EXAMPLE CODE
*
*                             (c) Copyright 2012; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                           EXAMPLE CODE
*
*                                           CYPRESS PSoC5
*                                              with the
*                                     CY8CKIT-050 Development Kit
*
* Filename      : app.c
* Version       : V1.00
* Programmer(s) : DC
                  
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/

#include <includes.h>


/*
*********************************************************************************************************
*                                             LOCAL DEFINES
*********************************************************************************************************
*/

#define  APP_USER_IF_SIGN_ON                        0u
#define  APP_USER_IF_VER_TICK_RATE                  1u
#define  APP_USER_IF_CPU                            2u
#define  APP_USER_IF_CTXSW                          3u
#define  APP_USER_IF_STATE_MAX                      4u

/*
*********************************************************************************************************
*                                            LOCAL VARIABLES
*********************************************************************************************************
*/

static  OS_TCB   App_TaskStartTCB;
static  CPU_STK  App_TaskStartStk[APP_CFG_TASK_START_STK_SIZE];

static  OS_TCB   App_TaskUserIF_TCB;
static  CPU_STK  App_TaskUserIFStk[APP_CFG_TASK_USER_IF_STK_SIZE];


/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  void  App_TaskStart  (void *p_arg);

static  void  App_TaskUserIF (void *p_arg);

static  void  App_TaskCreate (void);
static  void  App_ObjCreate  (void);

/*
*********************************************************************************************************
*                                                main()
*
* Description : This is the standard entry point for C code.  It is assumed that your code will call
*               main() once you have performed all necessary initialization.
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : Startup Code.
*
* Note(s)     : none.
*********************************************************************************************************
*/

int  main (void)
{
    OS_ERR  os_err;


    BSP_PreInit();                                              /* Perform BSP pre-initialization.                      */

    CPU_Init();                                                 /* Initialize the uC/CPU services                       */

    OSInit(&os_err);                                            /* Init uC/OS-III.                                      */

    OSTaskCreate((OS_TCB      *)&App_TaskStartTCB,              /* Create the start task                                */
                 (CPU_CHAR    *)"Start",
                 (OS_TASK_PTR  )App_TaskStart, 
                 (void        *)0,
                 (OS_PRIO      )APP_CFG_TASK_START_PRIO,
                 (CPU_STK     *)&App_TaskStartStk[0],
                 (CPU_STK_SIZE )APP_CFG_TASK_START_STK_SIZE_LIMIT,
                 (CPU_STK_SIZE )APP_CFG_TASK_START_STK_SIZE,
                 (OS_MSG_QTY   )0u,
                 (OS_TICK      )0u,
                 (void        *)0,
                 (OS_OPT       )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR      *)&os_err);

    OSStart(&os_err);                                            /* Start multitasking (i.e. give control to uC/OS-III).  */
}


/*
*********************************************************************************************************
*                                          App_TaskStart()
*
* Description : This is an example of a startup task.  As mentioned in the book's text, you MUST
*               initialize the ticker only once multitasking has started.
*
* Argument(s) : p_arg   is the argument passed to 'App_TaskStart()' by 'OSTaskCreate()'.
*
* Return(s)   : none
*
* Note(s)     : 1) The first line of code is used to prevent a compiler warning because 'p_arg' is not
*                  used.  The compiler should not generate any code for this statement.
*********************************************************************************************************
*/

static  void  App_TaskStart (void *p_arg)
{
    OS_ERR       err;
        

   (void)p_arg;
   

    BSP_PostInit();                                               /* Perform BSP post-initialization functions.       */
    
    BSP_CPU_TickInit();                                           /* Perfrom Tick Initialization                      */

#if (OS_CFG_STAT_TASK_EN > 0u)
    OSStatTaskCPUUsageInit(&err);
#endif    

#ifdef CPU_CFG_INT_DIS_MEAS_EN
    CPU_IntDisMeasMaxCurReset();
#endif      

    App_TaskCreate();                                             /* Create application tasks.                        */

    App_ObjCreate();                                              /* Create kernel objects                            */
    
#if (APP_CFG_PROBE_COM_EN == DEF_ENABLED)
    App_ProbeInit();                                              /* Enabling uC/Probe                                */
#endif
    
    BSP_LED_Off(0);

    while (DEF_TRUE) {                                            /* Task body, always written as an infinite loop.   */
        BSP_LED_Toggle(0);
        OSTimeDlyHMSM(0, 0, 0, 100, 
                      OS_OPT_TIME_HMSM_STRICT, 
                      &err);
    }
}


/*
*********************************************************************************************************
*                                          App_TaskCreate()
*
* Description : Create application tasks.
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : AppTaskStart()
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  App_TaskCreate (void)
{

    OS_ERR  os_err;

    
    OSTaskCreate((OS_TCB      *)&App_TaskUserIF_TCB,
                 (CPU_CHAR    *)"Start",
                 (OS_TASK_PTR  )App_TaskUserIF, 
                 (void        *)0,
                 (OS_PRIO      )APP_CFG_TASK_USER_IF_PRIO,
                 (CPU_STK     *)&App_TaskUserIFStk[0],
                 (CPU_STK_SIZE )APP_CFG_TASK_USER_IF_STK_SIZE_LIMIT,
                 (CPU_STK_SIZE )APP_CFG_TASK_USER_IF_STK_SIZE,
                 (OS_MSG_QTY   )0u,
                 (OS_TICK      )0u,
                 (void        *)0,
                 (OS_OPT       )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR      *)&os_err);
}


/*
*********************************************************************************************************
*                                          App_ObjCreate()
*
* Description : Create application kernel objects tasks.
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : AppTaskStart()
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  App_ObjCreate (void)
{

}


/*
*********************************************************************************************************
*                                          App_TaskUserIF()
*
* Description : User interface task
*
* Argument(s) : p_arg   is the argument passed to 'App_TaskUserIF()' by 'OSTaskCreate()'.
*
* Return(s)   : none
*
* Note(s)     : 1) The first line of code is used to prevent a compiler warning because 'p_arg' is not
*                  used.  The compiler should not generate any code for this statement.
*********************************************************************************************************
*/


static  void  App_TaskUserIF (void *p_arg)
{
   CPU_INT32U   val;
   CPU_INT08U   user_if_state_cur;
   CPU_INT08U   user_if_state_prev;   
   CPU_BOOLEAN  pb2_state_cur;
   CPU_BOOLEAN  pb2_state_prev;
   CPU_BOOLEAN  pb3_state_cur;
   CPU_BOOLEAN  pb3_state_prev;
   OS_ERR       os_err;
   CPU_CHAR     line_str[17];
   
   
   (void)p_arg;
   
   LCD_Disp_Start();                                             /* Initialize the LCD screen.                       */
   
   LCD_Disp_Position(0u, 0u);                                    /* Clear LCD screen                                 */
   LCD_Disp_PrintString((uint8 *)"                ");
   LCD_Disp_Position(1u, 0u);
   LCD_Disp_PrintString((uint8 *)"                ");
   
   LCD_Disp_PrintString((uint8 *)"Micrium uC/OS-III");

   user_if_state_cur  = APP_USER_IF_SIGN_ON;
   user_if_state_prev = APP_USER_IF_SIGN_ON;
   pb2_state_cur      = DEF_OFF;
   pb2_state_prev     = DEF_OFF;
   pb3_state_cur      = DEF_OFF;
   pb3_state_prev     = DEF_OFF;
   
   
    while (DEF_TRUE) {    

        if (user_if_state_cur != user_if_state_prev) {
            LCD_Disp_Position(0u, 0u);
            LCD_Disp_PrintString((uint8 *)"                ");
            LCD_Disp_Position(1u, 0u);
            LCD_Disp_PrintString((uint8 *)"                ");
            user_if_state_prev = user_if_state_cur;
        }

        switch (user_if_state_cur) {
            case APP_USER_IF_VER_TICK_RATE:
                 Str_Copy(line_str, "uC/OS-III Vx.yyy");
                 val          = (CPU_INT32U)OSVersion(&os_err);
                 line_str[11] = (val        )  / 1000u + '0';
                 line_str[13] = (val % 1000u)  /  100u + '0';
                 line_str[14] = (val %  100u)  /   10u + '0';
                 line_str[15] = (val %   10u)          + '0';
                 LCD_Disp_Position(0u, 0u);
                 LCD_Disp_PrintString((uint8 *)line_str);

                 Str_Copy(line_str, "TickRate:   xxxx");
                 val = (CPU_INT32U)OSCfg_TickRate_Hz;
                 Str_FmtNbr_Int32U((CPU_INT32U     )val, 
                                   (CPU_INT08U     )4u,
                                   (CPU_INT08U     )10,
                                   (CPU_CHAR       )0,
                                   (CPU_BOOLEAN    )DEF_NO,
                                   (CPU_BOOLEAN    )DEF_YES,
                                   (CPU_CHAR      *)&line_str[12]);
                 LCD_Disp_Position(1u, 0u);
                 LCD_Disp_PrintString((uint8 *)line_str);
                 break;

            case APP_USER_IF_CPU:
                 Str_Copy(line_str, "CPU Usage:xx %  ");
                 val          = (CPU_INT32U)OSStatTaskCPUUsage;
                 line_str[10] = (val / 10u) + '0';
                 line_str[11] = (val % 10u) + '0';
                 LCD_Disp_Position(0u, 0u);
                 LCD_Disp_PrintString((uint8 *)line_str);
                 
                 Str_Copy(line_str, "CPU Speed:xxxMHz");
                 val          = (CPU_INT32U)BSP_CPU_ClkFreq();
                 val         /= 1000000u;
                 line_str[10] = (val       ) / 100u + '0';
                 line_str[11] = (val % 100u) /  10u + '0';
                 line_str[12] = (val % 10u)         + '0';
                 LCD_Disp_Position(1u, 0u);
                 LCD_Disp_PrintString((uint8 *)line_str);
                 break;

            case APP_USER_IF_CTXSW:
                 Str_Copy(line_str, "#Ticks: xxxxxxxx");
                 val = (CPU_INT32U)OSTickCtr;
                 Str_FmtNbr_Int32U((CPU_INT32U     )val, 
                                   (CPU_INT08U     )8u,
                                   (CPU_INT08U     )10,
                                   (CPU_CHAR       )0,
                                   (CPU_BOOLEAN    )DEF_NO,
                                   (CPU_BOOLEAN    )DEF_YES,
                                   (CPU_CHAR      *)&line_str[8]);
                 LCD_Disp_Position(0u, 0u);
                 LCD_Disp_PrintString((uint8 *)line_str);
                 
                 Str_Copy(line_str, "#CtxSw: xxxxxxxx");
                 val          = (CPU_INT32U)OSTaskCtxSwCtr;
                 Str_FmtNbr_Int32U((CPU_INT32U     )val, 
                                   (CPU_INT08U     )8u,
                                   (CPU_INT08U     )10,
                                   (CPU_CHAR       )0,
                                   (CPU_BOOLEAN    )DEF_NO,
                                   (CPU_BOOLEAN    )DEF_YES,
                                   (CPU_CHAR      *)&line_str[8]);
                 LCD_Disp_Position(1u, 0u);
                 LCD_Disp_PrintString((uint8 *)line_str);
                 break;

            case APP_USER_IF_SIGN_ON:
            default:
                 LCD_Disp_Position(0u, 0u);
                 LCD_Disp_PrintString((uint8 *)"=== Micrium === ");
                 LCD_Disp_Position(1u, 0u);
                 LCD_Disp_PrintString((uint8 *)"   uC/OS-III    ");
                 break;
        }

        pb2_state_cur = BSP_PB_StatusGet(2);
        pb3_state_cur = BSP_PB_StatusGet(3);
        if ((pb2_state_cur  == DEF_ON ) &&
            (pb2_state_prev == DEF_OFF)) {     
            user_if_state_cur = (user_if_state_cur + 1u) % APP_USER_IF_STATE_MAX;
        }

        if ((pb3_state_cur  == DEF_ON ) &&
            (pb3_state_prev == DEF_OFF)) { 
            user_if_state_cur = (user_if_state_cur - 1u) % APP_USER_IF_STATE_MAX;
        }

        OSTimeDlyHMSM(0, 0, 0, 100, 
                      OS_OPT_TIME_HMSM_STRICT, 
                      &os_err);

        pb2_state_prev = pb2_state_cur;
        pb3_state_prev = pb3_state_cur;	
    }
}
